import React, { useState } from 'react';
import { ShieldCheck, Edit3 } from 'lucide-react';
import { Card } from './UI';
import { cn } from '../../utils';

export function ProfileView({ user, setUsers, users }: any) {
  const [editing, setEditing] = useState(false);
  const [phone, setPhone] = useState(user.phone);

  const handleUpdate = () => {
    const updatedUsers = users.map((u: any) => u.id === user.id ? { ...u, phone } : u);
    setUsers(updatedUsers);
    setEditing(false);
    alert('Identity Packet Updated.');
    // Update current user in session too
    localStorage.setItem('se_session', JSON.stringify({ ...user, phone }));
  };

  return (
    <div className="max-w-3xl mx-auto space-y-10">
      <div className="text-center space-y-4">
        <div className="w-32 h-32 rounded-[2.5rem] bg-zinc-900 mx-auto flex items-center justify-center text-white text-5xl font-black shadow-2xl shadow-zinc-900/30 relative group overflow-hidden">
           {user.name[0]}
           <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer">
             <Edit3 size={32} />
           </div>
        </div>
        <div>
          <h1 className="text-4xl font-black text-zinc-900 tracking-tighter uppercase">{user.name}</h1>
          <p className="text-[10px] font-black text-zinc-400 uppercase tracking-[0.3em] mt-1">{user.id.toUpperCase()} · Persistent Identity</p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <Card title="Account Integrity" subtitle="Identity information stored in sector directory" className="border-none shadow-2xl shadow-zinc-100/50">
          <div className="space-y-8 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-2 block">System Identifier</label>
                <input disabled value={user.email} className="w-full bg-zinc-50 border border-zinc-200 rounded-2xl p-4 text-sm font-black text-zinc-400 outline-none cursor-not-allowed opacity-60" />
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-1 block">Role Clearance</label>
                <div className="bg-zinc-900 text-white p-4 rounded-2xl text-sm font-black uppercase tracking-widest flex items-center gap-3">
                   <ShieldCheck size={18} className="text-emerald-500" />
                   {user.role} Authorization
                </div>
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-2 block">Mobile Linkage</label>
                <div className="relative">
                  <input 
                    value={phone} 
                    onChange={(e) => setPhone(e.target.value)} 
                    disabled={!editing} 
                    className={cn(
                      "w-full rounded-2xl p-4 text-sm font-black transition-all outline-none",
                      editing ? "bg-white border-2 border-zinc-900 ring-4 ring-zinc-100" : "bg-zinc-50 border border-zinc-200 text-zinc-900 cursor-not-allowed"
                    )} 
                  />
                  {!editing && (
                    <button onClick={() => setEditing(true)} className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-900">
                      <Edit3 size={16} />
                    </button>
                  )}
                </div>
              </div>
              {editing && (
                <div className="flex items-end gap-3">
                  <button onClick={handleUpdate} className="flex-1 bg-zinc-900 text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition shadow-xl shadow-zinc-900/10">Commit Changes</button>
                  <button onClick={() => { setEditing(false); setPhone(user.phone); }} className="px-6 bg-zinc-100 text-zinc-500 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-200 transition">Cancel</button>
                </div>
              )}
            </div>
            
            <div className="pt-8 border-t border-zinc-100 flex items-center justify-between">
              <div className="flex flex-col">
                <span className="text-[10px] font-black text-zinc-900 uppercase tracking-widest">Identity Status</span>
                <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mt-0.5">Verified Network Member</span>
              </div>
              <button className="text-rose-500 text-[10px] font-black uppercase tracking-widest hover:underline">Revoke Authorization</button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
