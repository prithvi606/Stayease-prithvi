import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Star } from 'lucide-react';
import { Card } from './UI';
import { cn } from '../../utils';
import { Feedback } from '../../types';

export function FeedbackView({ feedbacks, setFeedbacks, user, users }: any) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newFeedback: Feedback = {
      id: Math.random().toString(36).substr(2, 9),
      userId: user.id,
      rating,
      comment,
      createdAt: new Date().toISOString().split('T')[0]
    };
    setFeedbacks([newFeedback, ...feedbacks]);
    setComment('');
    setRating(5);
  };

  const filteredFeedbacks = user.role === 'admin' ? feedbacks : feedbacks.filter((f: any) => f.userId === user.id);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-black text-zinc-900 tracking-tighter uppercase">{user.role === 'admin' ? 'Community Feedback' : 'My Feedback'}</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {user.role === 'resident' && (
          <Card title="Share Experience" subtitle="Help us improve your stay" className="lg:col-span-1 border-none shadow-2xl shadow-indigo-100/50">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-3 block">Rating</label>
                <div className="flex gap-2">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <button 
                      key={s}
                      type="button"
                      onClick={() => setRating(s)}
                      className={cn(
                        "w-10 h-10 rounded-xl flex items-center justify-center transition-all",
                        rating >= s ? "bg-amber-400 text-white shadow-lg shadow-amber-200" : "bg-zinc-100 text-zinc-400"
                      )}
                    >
                      <Star size={18} fill={rating >= s ? "currentColor" : "none"} />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-2 block">Comment</label>
                <textarea 
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="w-full bg-zinc-50 border border-zinc-200 rounded-2xl p-4 text-sm font-medium focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none min-h-[120px]"
                  placeholder="Tell us what you like or how we can improve..."
                  required
                />
              </div>
              <button className="w-full bg-zinc-900 text-white py-4 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-zinc-800 transition shadow-xl shadow-zinc-900/10">
                Submit Feedback
              </button>
            </form>
          </Card>
        )}

        <div className={cn("space-y-6", user.role === 'resident' ? "lg:col-span-2" : "lg:col-span-3")}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredFeedbacks.map((f: Feedback) => {
              const u = users.find((x: any) => x.id === f.userId);
              return (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  key={f.id} 
                  className="bg-white border border-zinc-200 rounded-[2.5rem] p-8 shadow-sm hover:shadow-xl transition-all group"
                >
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-zinc-900 flex items-center justify-center text-white text-xs font-black">
                        {u?.name[0]}
                      </div>
                      <div>
                        <p className="text-sm font-black text-zinc-900 tracking-tight">{u?.name}</p>
                        <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-widest">{f.createdAt}</p>
                      </div>
                    </div>
                    <div className="flex gap-0.5">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star key={s} size={12} className={f.rating >= s ? "text-amber-400 fill-amber-400" : "text-zinc-200"} />
                      ))}
                    </div>
                  </div>
                  <p className="text-zinc-600 text-sm leading-relaxed italic font-medium">"{f.comment}"</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
