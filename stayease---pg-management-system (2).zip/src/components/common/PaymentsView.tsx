import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, X, CheckCircle2 } from 'lucide-react';
import { Card, Badge } from './UI';
import { cn } from '../../utils';
import { Payment } from '../../types';

export function PaymentsView({ payments, setPayments, users, isAdmin, currentUserId }: any) {
  const [isAdding, setIsAdding] = useState(false);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as any;
    const newPayment: Payment = {
      id: `p${Date.now()}`,
      userId: form.userId?.value || currentUserId,
      amount: Number(form.amount.value),
      month: form.month.value,
      year: 2026,
      status: 'Pending',
      date: new Date().toISOString().split('T')[0],
      method: form.method.value,
    };
    setPayments([newPayment, ...payments]);
    setIsAdding(false);
  };

  const filteredPayments = isAdmin ? payments : payments.filter((p: any) => p.userId === currentUserId);
  const paidPayments = filteredPayments.filter((p:any)=>p.status==='Paid');
  const pendingPayments = filteredPayments.filter((p:any)=>p.status==='Pending');

  const markPaid = (id: string) => {
    setPayments(payments.map((p: any) => p.id === id ? { ...p, status: 'Paid' } : p));
  };

  return (
    <div className="space-y-6">
       <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-zinc-900 tracking-tight">{isAdmin ? 'Financial Ledger' : 'My Payments'}</h1>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-emerald-600 text-white px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:bg-emerald-700 transition shadow-lg shadow-emerald-600/20"
        >
          <Plus size={18} /> {isAdmin ? 'Record Fee' : 'Direct Payment'}
        </button>
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="mb-8 p-8 bg-emerald-600 rounded-[2.5rem] text-white shadow-2xl shadow-emerald-600/20">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-black uppercase tracking-tighter">{isAdmin ? 'New Transaction Record' : 'Initiate Payment Protocol'}</h3>
              <button onClick={() => setIsAdding(false)} className="text-emerald-200 hover:text-white"><X size={20} /></button>
            </div>
            <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {isAdmin ? (
                <select name="userId" required className="bg-white/10 border border-white/20 rounded-xl p-3 text-xs font-bold outline-none appearance-none">
                  <option value="" className="text-black">Select Resident</option>
                  {users.filter((u:any)=>u.role==='resident').map((u:any)=>(
                    <option key={u.id} value={u.id} className="text-black">{u.name}</option>
                  ))}
                </select>
              ) : (
                <div className="bg-white/10 border border-white/20 rounded-xl p-3 text-xs font-bold flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full bg-emerald-300 animate-pulse" />
                   {users.find((u:any)=>u.id === currentUserId)?.name || 'Authenticated User'}
                </div>
              )}
              <input name="amount" type="number" placeholder="Amount ₹" required className="bg-white/10 border border-white/20 rounded-xl p-3 text-xs font-bold outline-none" />
              <select name="month" className="bg-white/10 border border-white/20 rounded-xl p-3 text-xs font-bold outline-none appearance-none">
                {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(m => (
                  <option key={m} value={m} className="text-black">{m}</option>
                ))}
              </select>
              <select name="method" className="bg-white/10 border border-white/20 rounded-xl p-3 text-xs font-bold outline-none appearance-none">
                <option value="UPI" className="text-black">UPI</option>
                <option value="Cash" className="text-black">Cash</option>
                <option value="Bank Transfer" className="text-black">Bank Transfer</option>
              </select>
              <button type="submit" className="md:col-span-1 bg-white text-emerald-600 font-black uppercase text-[10px] tracking-widest rounded-xl hover:bg-zinc-100 transition shadow-lg">Execute Entry</button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="p-8 rounded-[2.5rem] bg-emerald-600 text-white shadow-2xl shadow-emerald-600/30 relative overflow-hidden group">
           <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 blur-3xl rounded-full -mr-16 -mt-16 transition-all group-hover:scale-150" />
           <p className="text-[10px] font-black text-emerald-100 uppercase tracking-widest opacity-60">{isAdmin ? 'Total Revenue' : 'Total Paid'}</p>
           <p className="text-4xl font-black mt-3 tracking-tighter relative z-10">₹{paidPayments.reduce((s:number,p:any)=>s+p.amount,0).toLocaleString()}</p>
        </div>
        <div className="p-8 rounded-[2.5rem] bg-zinc-900 text-white shadow-2xl shadow-zinc-900/30 relative overflow-hidden group">
           <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 blur-3xl rounded-full -mr-16 -mt-16 transition-all group-hover:scale-150" />
           <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest opacity-60">{isAdmin ? 'Outstanding' : 'Current Dues'}</p>
           <p className="text-4xl font-black mt-3 tracking-tighter relative z-10 text-rose-500">₹{pendingPayments.reduce((s:number,p:any)=>s+p.amount,0).toLocaleString()}</p>
        </div>
        <div className="p-8 rounded-[2.5rem] bg-indigo-600 text-white shadow-2xl shadow-indigo-600/30 relative overflow-hidden group">
           <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 blur-3xl rounded-full -mr-16 -mt-16 transition-all group-hover:scale-150" />
           <p className="text-[10px] font-black text-indigo-100 uppercase tracking-widest opacity-60">Status</p>
           <p className="text-2xl font-black mt-3 tracking-tighter relative z-10">
             {isAdmin ? `${((paidPayments.length / (filteredPayments.length || 1)) * 100).toFixed(1)}%` : pendingPayments.length === 0 ? 'Fully Settled' : 'Action Required'}
           </p>
        </div>
      </div>

      <Card className="p-0 overflow-hidden shadow-[0_30px_60px_-15px_rgba(0,0,0,0.05)] border-zinc-100">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
             <thead>
              <tr className="bg-zinc-50 border-b border-zinc-200">
                <th className="px-10 py-6 text-[10px] font-black text-zinc-400 uppercase tracking-[0.2em]">{isAdmin ? 'Payer Identity' : 'Transaction ID'}</th>
                <th className="px-10 py-6 text-[10px] font-black text-zinc-400 uppercase tracking-[0.2em]">Value</th>
                <th className="px-10 py-6 text-[10px] font-black text-zinc-400 uppercase tracking-[0.2em]">Fiscal Cycle</th>
                <th className="px-10 py-6 text-[10px] font-black text-zinc-400 uppercase tracking-[0.2em]">Protocol Status</th>
                <th className="px-10 py-6 text-[10px] font-black text-zinc-400 uppercase tracking-[0.2em]">Channel</th>
                <th className="px-10 py-6 text-[10px] font-black text-zinc-400 uppercase tracking-[0.2em] text-right">Integrity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {filteredPayments.map((p: Payment) => {
                const u = users.find((x: any) => x.id === p.userId);
                return (
                   <tr key={p.id} className="hover:bg-zinc-50/50 transition-colors">
                     <td className="px-10 py-6 text-sm font-black text-zinc-900 tracking-tight">{isAdmin ? u?.name : p.id.toUpperCase()}</td>
                     <td className="px-10 py-6 text-base font-black text-zinc-900 tracking-tighter">₹{p.amount.toLocaleString()}</td>
                     <td className="px-10 py-6 text-[10px] font-black text-zinc-400 uppercase tracking-wider">{p.month} {p.year}</td>
                     <td className="px-10 py-6">
                       <Badge variant={p.status === 'Paid' ? 'success' : 'warning'}>{p.status}</Badge>
                     </td>
                     <td className="px-10 py-6 text-xs text-zinc-500 font-bold uppercase tracking-tight">{p.method || '—'}</td>
                     <td className="px-10 py-6 text-right">
                        {p.status === 'Pending' ? (
                          <button 
                            onClick={() => markPaid(p.id)} 
                            className={cn(
                              "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition",
                              isAdmin ? "bg-zinc-900 text-white hover:bg-zinc-800" : "bg-emerald-600 text-white hover:bg-emerald-700"
                            )}
                          >
                            {isAdmin ? 'Settle' : 'Pay Now'}
                          </button>
                        ) : (
                          <div className="flex items-center justify-end gap-2 text-emerald-500">
                            <span className="text-[8px] font-black uppercase">Verified</span>
                            <CheckCircle2 size={18} />
                          </div>
                        )}
                      </td>
                  </tr>
                )
              })}
              {filteredPayments.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-8 py-20 text-center text-zinc-400 font-black uppercase tracking-widest text-xs">No transaction history found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
