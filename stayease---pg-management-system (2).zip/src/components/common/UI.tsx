import React from 'react';
import { motion } from 'motion/react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { cn } from '../../utils';

export const Badge = ({ children, variant = 'default', className }: { children: React.ReactNode, variant?: 'default' | 'success' | 'warning' | 'danger' | 'info', className?: string }) => {
  const styles = {
    default: 'bg-zinc-100 text-zinc-600 border border-zinc-200',
    success: 'bg-emerald-50 text-emerald-700 border border-emerald-200',
    warning: 'bg-amber-50 text-amber-700 border border-amber-200',
    danger: 'bg-rose-50 text-rose-700 border border-rose-200',
    info: 'bg-blue-50 text-blue-700 border border-blue-200',
  };
  return <span className={cn('px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider', styles[variant], className)}>{children}</span>;
};

export const Card = ({ children, className, title, subtitle, action }: any) => (
  <motion.div 
    initial={{ opacity: 0, y: 10 }}
    animate={{ opacity: 1, y: 0 }}
    className={cn('bg-white border border-zinc-200 rounded-[2.5rem] overflow-hidden shadow-sm shadow-zinc-200/40 hover:shadow-2xl hover:shadow-zinc-200/60 transition-all duration-500', className)}
  >
    {(title || action) && (
      <div className="px-8 py-6 border-b border-zinc-100 flex items-center justify-between">
        <div>
          {title && <h3 className="font-black text-xs uppercase tracking-[0.1em] text-zinc-900">{title}</h3>}
          {subtitle && <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mt-1 opacity-60">{subtitle}</p>}
        </div>
        {action && <div>{action}</div>}
      </div>
    )}
    <div className="p-8">{children}</div>
  </motion.div>
);

export const StatCard = ({ label, value, icon: Icon, trend, color }: any) => (
  <div className={cn("p-8 rounded-[2.5rem] text-white shadow-2xl transition-all duration-500 hover:-translate-y-1 relative overflow-hidden group flex flex-col justify-between h-[200px]", color)}>
    <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 blur-3xl rounded-full -mr-16 -mt-16 transition-all group-hover:scale-150" />
    <div className="flex justify-between items-start relative z-10">
      <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center">
        <Icon size={24} className="text-white" />
      </div>
      {trend && (
        <div className={cn("flex items-center gap-1 px-3 py-1.5 rounded-full text-[10px] font-black backdrop-blur-md bg-white/20")}>
          {trend > 0 ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
          {Math.abs(trend)}%
        </div>
      )}
    </div>
    <div className="relative z-10">
      <p className="text-[10px] font-black uppercase tracking-[0.2em] opacity-60 mb-1">{label}</p>
      <p className="text-4xl font-black tracking-tighter">{value}</p>
    </div>
  </div>
);

export function NavItem({ icon: Icon, label, active, onClick, collapsed, badge, colorClass }: any) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 relative group",
        active 
          ? cn("shadow-xl text-white", colorClass || "bg-zinc-900 shadow-zinc-900/20") 
          : "text-zinc-400 hover:text-zinc-900 hover:bg-zinc-50"
      )}
    >
      <Icon size={20} className={cn("transition-transform group-hover:scale-110", active ? "text-white" : "text-zinc-400")} />
      {!collapsed && <span className="font-black text-[10px] uppercase tracking-[0.2em]">{label}</span>}
      {badge && !collapsed && (
        <span className="ml-auto bg-white text-zinc-900 text-[10px] font-black px-2 py-0.5 rounded-full shadow-lg">
          {badge}
        </span>
      )}
      {active && !collapsed && <div className="absolute right-4 top-1/2 -translate-y-1/2 w-1.5 h-1.5 bg-white rounded-full opacity-50" />}
    </button>
  );
}
