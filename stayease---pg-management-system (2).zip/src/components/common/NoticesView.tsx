import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, X, ShieldCheck } from 'lucide-react';
import { cn } from '../../utils';
import { Notice } from '../../types';

export function NoticesView({ notices, setNotices, isAdmin }: any) {
  const [isAdding, setIsAdding] = useState(false);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as any;
    const newNotice: Notice = {
      id: `n${Date.now()}`,
      title: form.title.value,
      content: form.content.value,
      priority: form.priority.value as any,
      date: new Date().toISOString().split('T')[0],
    };
    setNotices([newNotice, ...notices]);
    setIsAdding(false);
  };

  return (
    <div className="space-y-6">
       <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-zinc-900 tracking-tight">Public Terminal</h1>
        {isAdmin && (
          <button 
            onClick={() => setIsAdding(true)}
            className="bg-zinc-900 text-white px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:bg-zinc-800 transition shadow-lg shadow-zinc-900/20"
          >
            <Plus size={18} /> New Broadcast
          </button>
        )}
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="mb-8 p-8 bg-zinc-900 rounded-[2.5rem] text-white">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-black uppercase tracking-tighter">Global Broadcast</h3>
              <button onClick={() => setIsAdding(false)} className="text-zinc-500 hover:text-white"><X size={20} /></button>
            </div>
            <form onSubmit={handleAdd} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input name="title" type="text" placeholder="Title" required className="bg-white/10 border border-white/20 rounded-xl p-4 text-xs font-bold outline-none" />
                <select name="priority" className="bg-white/10 border border-white/20 rounded-xl p-4 text-xs font-bold outline-none appearance-none">
                  <option value="Normal" className="text-black">Normal Priority</option>
                  <option value="High" className="text-black">High Priority</option>
                  <option value="Low" className="text-black">Low Priority</option>
                </select>
              </div>
              <textarea name="content" placeholder="Broadcast Content..." required className="w-full bg-white/10 border border-white/20 rounded-xl p-4 text-xs font-bold outline-none min-h-[100px]" />
              <button type="submit" className="w-full bg-white text-zinc-900 font-black uppercase text-[10px] tracking-widest py-4 rounded-xl hover:bg-zinc-200 transition">Authorize Broadcast</button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {notices.map((n: Notice) => (
          <div key={n.id} className="bg-white border border-zinc-200 rounded-[3rem] p-10 relative overflow-hidden flex flex-col justify-between shadow-[0_20px_50px_-12px_rgba(0,0,0,0.05)] group hover:-translate-y-2 transition-all duration-500">
             <div className={cn(
                "absolute top-0 right-0 px-8 py-3 text-[10px] font-black uppercase tracking-widest text-white shadow-2xl",
                n.priority === 'High' ? 'bg-rose-600 shadow-rose-600/30' : n.priority === 'Normal' ? 'bg-zinc-900 shadow-zinc-900/30' : 'bg-cyan-600 shadow-cyan-600/30'
             )}>
                {n.priority} Channel
              </div>
             
             <div className="relative z-10">
               <h3 className="text-3xl font-black text-zinc-900 mb-6 tracking-tighter uppercase leading-none">{n.title}</h3>
               <p className="text-zinc-500 text-sm leading-relaxed mb-10 font-medium">{n.content}</p>
             </div>

             <div className="flex items-center justify-between pt-8 border-t border-zinc-100 relative z-10">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-zinc-50 border border-zinc-100/50 rounded-2xl flex items-center justify-center text-zinc-400">
                    <ShieldCheck size={20} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-zinc-900 uppercase tracking-widest">Authority</span>
                    <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">STAYEASE_CORE_OPS</span>
                  </div>
                </div>
                <div className="text-right flex flex-col">
                  <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Relay Time</span>
                  <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-widest font-mono">{n.date}</span>
                </div>
             </div>
          </div>
        ))}
      </div>
    </div>
  );
}
