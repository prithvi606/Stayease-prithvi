import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, X, ClipboardList, UserCircle, Clock, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Badge } from './UI';
import { cn } from '../../utils';
import { Complaint } from '../../types';

export function ComplaintsView({ complaints, setComplaints, user, users, isAdmin }: any) {
  const [isAdding, setIsAdding] = useState(false);
  const [selectedComplaint, setSelectedComplaint] = useState<Complaint | null>(null);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as any;
    const newComplaint: Complaint = {
      id: `c${Date.now()}`,
      userId: user.id,
      title: form.title.value,
      description: form.description.value,
      category: form.category.value,
      status: 'Pending',
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };
    setComplaints([newComplaint, ...complaints]);
    setIsAdding(false);
  };

  const resolveComplaint = (id: string) => {
    setComplaints(complaints.map((c: any) => c.id === id ? { ...c, status: 'Resolved' } : c));
    if (selectedComplaint?.id === id) {
      setSelectedComplaint({ ...selectedComplaint, status: 'Resolved' });
    }
  };

  const filtered = isAdmin ? complaints : complaints.filter((c: any) => c.userId === user.id);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-zinc-900 tracking-tight">System Tickets</h1>
        {!isAdmin && (
          <button 
            onClick={() => setIsAdding(true)}
            className="bg-rose-600 text-white px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center gap-2 hover:bg-rose-700 transition shadow-lg shadow-rose-600/20"
          >
            <Plus size={18} /> Raise Issue
          </button>
        )}
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="mb-8 p-10 bg-rose-600 rounded-[3rem] text-white shadow-2xl shadow-rose-600/20">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-black uppercase tracking-tighter">Support Incident Report</h3>
              <button onClick={() => setIsAdding(false)} className="text-rose-200 hover:text-white"><X size={24} /></button>
            </div>
            <form onSubmit={handleAdd} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <input name="title" type="text" placeholder="Short summary of issue" required className="bg-white/10 border border-white/20 rounded-2xl p-4 text-sm font-bold outline-none placeholder:text-rose-200" />
                <select name="category" className="bg-white/10 border border-white/20 rounded-2xl p-4 text-sm font-bold outline-none appearance-none">
                  <option value="Maintenance" className="text-black">Maintenance</option>
                  <option value="Housekeeping" className="text-black">Housekeeping</option>
                  <option value="Security" className="text-black">Security</option>
                  <option value="Billing" className="text-black">Billing</option>
                  <option value="Wifi" className="text-black">High Speed Wifi</option>
                </select>
              </div>
              <textarea name="description" placeholder="Describe the problem in detail..." required className="w-full bg-white/10 border border-white/20 rounded-2xl p-4 text-sm font-bold outline-none min-h-[120px] placeholder:text-rose-200" />
              <button type="submit" className="w-full bg-white text-rose-600 py-4 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-zinc-100 transition shadow-xl">Transmit Ticket</button>
            </form>
          </motion.div>
        )}

        {selectedComplaint && (
          <motion.div 
            initial={{ opacity: 0 }} 
            animate={{ opacity: 1 }} 
            exit={{ opacity: 0 }} 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedComplaint(null)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }} 
              animate={{ scale: 1, y: 0 }} 
              className="bg-white rounded-[2.5rem] w-full max-w-2xl overflow-hidden shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className={cn(
                "p-10 text-white relative",
                selectedComplaint.status === 'Resolved' ? 'bg-emerald-600' : 'bg-rose-600'
              )}>
                <button 
                  onClick={() => setSelectedComplaint(null)}
                  className="absolute top-8 right-8 text-white/50 hover:text-white transition-colors"
                >
                  <X size={24} />
                </button>
                <Badge variant={selectedComplaint.status === 'Resolved' ? 'success' : 'warning'} className="bg-white/20 text-white border-none mb-4">
                  {selectedComplaint.status}
                </Badge>
                <h2 className="text-4xl font-black uppercase tracking-tight leading-none mb-2">{selectedComplaint.title}</h2>
                <div className="flex items-center gap-4 text-white/70 text-[10px] font-black uppercase tracking-widest">
                  <span>ID: {selectedComplaint.id}</span>
                  <span>•</span>
                  <span>{selectedComplaint.category}</span>
                </div>
              </div>

              <div className="p-10 space-y-8">
                <div className="space-y-4">
                  <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400">Description</p>
                  <p className="text-zinc-600 font-medium leading-relaxed">{selectedComplaint.description}</p>
                </div>

                <div className="grid grid-cols-2 gap-8 border-t border-zinc-100 pt-8">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400 mb-2">Submitted By</p>
                    <p className="font-bold text-zinc-900">{users.find((u:any) => u.id === selectedComplaint.userId)?.name || 'Unknown User'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-400 mb-2">Timestamp</p>
                    <p className="font-bold text-zinc-900">{selectedComplaint.createdAt}</p>
                  </div>
                </div>

                {isAdmin && selectedComplaint.status !== 'Resolved' && (
                  <button 
                    onClick={() => resolveComplaint(selectedComplaint.id)}
                    className="w-full bg-zinc-900 text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition shadow-xl"
                  >
                    Mark as Resolved
                  </button>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 gap-6">
        {filtered.map((c: Complaint) => {
          const reporter = users.find((u:any) => u.id === c.userId);
          return (
            <motion.div 
              whileHover={{ scale: 1.005 }}
              key={c.id} 
              className="bg-white border border-zinc-200 rounded-3xl p-8 flex flex-col md:flex-row gap-8 relative group overflow-hidden shadow-sm shadow-zinc-200/50"
            >
              <div className={cn(
                "absolute left-0 top-0 bottom-0 w-2",
                c.status === 'Resolved' ? 'bg-emerald-500' : c.status === 'In-Progress' ? 'bg-blue-600' : 'bg-rose-500'
              )} />
              
              <div className="flex-1">
                <div className="flex items-center gap-4 mb-3">
                  <h3 className="font-black text-zinc-900 text-lg uppercase tracking-tight">{c.title}</h3>
                  <Badge variant={c.status === 'Resolved' ? 'success' : c.status === 'In-Progress' ? 'info' : 'danger'}>{c.status}</Badge>
                </div>
                <p className="text-zinc-500 text-sm leading-relaxed mb-6 font-medium line-clamp-2">{c.description}</p>
                
                <div className="flex items-center gap-8 flex-wrap">
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-400 border border-zinc-200">
                      <ClipboardList size={12} />
                    </div>
                    <span className="text-[10px] text-zinc-400 font-black uppercase tracking-widest">{c.category}</span>
                  </div>
                  {isAdmin && (
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-400 border border-zinc-200">
                        <UserCircle size={12} />
                      </div>
                      <span className="text-[10px] text-zinc-400 font-black uppercase tracking-widest">{reporter?.name || 'Unknown'}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-2">
                    <div className="w-6 h-6 rounded-lg bg-zinc-100 flex items-center justify-center text-zinc-400 border border-zinc-200">
                      <Clock size={12} />
                    </div>
                    <span className="text-[10px] text-zinc-400 font-black uppercase tracking-widest">TS: {c.createdAt}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                {isAdmin && c.status !== 'Resolved' && (
                  <button 
                  onClick={() => resolveComplaint(c.id)}
                  className="bg-zinc-900 text-white px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition shadow-lg shadow-zinc-900/10"
                  >
                    Resolve
                  </button>
                )}
                <button 
                  onClick={() => setSelectedComplaint(c)}
                  className="bg-white text-zinc-900 px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest border border-zinc-200 hover:bg-zinc-50 transition shadow-sm"
                >
                  View Entry
                </button>
              </div>
            </motion.div>
          );
        })}
        {filtered.length === 0 && (
          <div className="text-center py-20 bg-zinc-50 rounded-[3rem] border border-dashed border-zinc-200">
            <p className="text-zinc-400 font-black uppercase tracking-widest text-xs">No active incidents found in terminal</p>
          </div>
        )}
      </div>
    </div>
  );
}
