import React from 'react';
import { Building2, ShieldCheck } from 'lucide-react';
import { Card, Badge } from '../common/UI';

export function UnitView({ user, rooms, payments, users, setPayments }: any) {
  const room = rooms.find((r: any) => r.id === user.roomId);
  const myPayments = payments.filter((p: any) => p.userId === user.id);
  const lastPayment = myPayments[0];
  const roommates = users.filter((u: any) => u.roomId === user.roomId && u.id !== user.id);

  const markPaid = (id: string) => {
    setPayments(payments.map((p: any) => p.id === id ? { ...p, status: 'Paid' } : p));
  };

  if (!room) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-white border border-zinc-200 rounded-[3rem] shadow-sm">
        <Building2 size={48} className="text-zinc-200 mb-6" />
        <h2 className="text-xl font-black uppercase text-zinc-900 tracking-tighter">No Active Assignment</h2>
        <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest mt-2 px-10 text-center">Your profile is currently not linked to any operational node.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-black text-zinc-900 tracking-tighter uppercase">My Operational Unit</h1>
        <Badge variant="success">Assigned</Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card className="md:col-span-2 border-none shadow-2xl shadow-indigo-100/30 overflow-hidden" title="Unit Configuration" subtitle={`Node ${room.number}`}>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
             <div>
               <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-1">Architecture</p>
               <p className="text-lg font-black text-zinc-900">{room.type} Suite</p>
             </div>
             <div>
               <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-1">Elevation</p>
               <p className="text-lg font-black text-zinc-900">Level {room.floor}</p>
             </div>
             <div>
               <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-1">Monthly Cost</p>
               <p className="text-lg font-black text-zinc-900 font-mono">₹{room.rent.toLocaleString()}</p>
             </div>
          </div>
          
          <div className="mt-10">
            <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400 mb-4">Active Utilities</p>
            <div className="flex flex-wrap gap-2">
              {room.amenities.map((a: string) => (
                <span key={a} className="bg-zinc-100 text-zinc-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border border-zinc-200 flex items-center gap-2">
                  <ShieldCheck size={12} className="text-emerald-500" />
                  {a}
                </span>
              ))}
            </div>
          </div>
        </Card>

        <Card title="Current Allocation" className="border-none shadow-xl shadow-zinc-100/50 flex flex-col justify-center text-center">
            <div className="relative w-40 h-40 mx-auto mb-6">
              <svg className="w-full h-full -rotate-90">
                <circle cx="80" cy="80" r="70" className="stroke-zinc-100 fill-none" strokeWidth="15" />
                <circle cx="80" cy="80" r="70" className="stroke-indigo-600 fill-none" strokeWidth="15" strokeDasharray="439.8" strokeDashoffset={439.8 * (1 - room.occupancy/room.capacity)} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-4xl font-black text-zinc-900">{room.occupancy}/{room.capacity}</span>
                <span className="text-[8px] font-black text-zinc-400 uppercase tracking-[0.2em] mt-1">Personnel</span>
              </div>
            </div>
            <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Occupancy Load Indicator</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        <Card title="Unit Roommates" className="lg:col-span-1 border-none shadow-xl shadow-purple-100/30">
          <div className="space-y-4">
             {roommates.length > 0 ? roommates.map((rm: any) => (
               <div key={rm.id} className="flex items-center gap-3 p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                  <div className="w-10 h-10 rounded-xl bg-zinc-900 flex items-center justify-center text-white font-black text-xs">
                    {rm.name[0]}
                  </div>
                  <div>
                    <p className="text-xs font-black text-zinc-900 uppercase tracking-tight">{rm.name}</p>
                    <p className="text-[8px] font-bold text-zinc-400 uppercase tracking-widest">Active Link</p>
                  </div>
               </div>
             )) : (
               <div className="text-center py-10 text-zinc-400 text-[10px] font-black uppercase tracking-widest">Solitary Allocation</div>
             )}
          </div>
        </Card>

        <Card title="Latest Transaction" className="lg:col-span-1 border-none shadow-xl shadow-emerald-100/30">
          {lastPayment ? (
            <div className="flex flex-col bg-zinc-50 p-6 rounded-[2rem] border border-zinc-100 h-full min-h-[90px] justify-between">
               <div className="flex items-center justify-between">
                 <div>
                   <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400">Payment ID</p>
                   <p className="text-sm font-black text-zinc-900 mt-1 uppercase">{lastPayment.id}</p>
                 </div>
                 <div className="text-right">
                    <p className="text-xl font-black text-zinc-900 tracking-tighter">₹{lastPayment.amount.toLocaleString()}</p>
                    <Badge variant={lastPayment.status === 'Paid' ? 'success' : 'warning'}>{lastPayment.status}</Badge>
                 </div>
               </div>
               {lastPayment.status === 'Pending' && (
                 <button 
                  onClick={() => markPaid(lastPayment.id)}
                  className="mt-6 w-full bg-emerald-600 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition shadow-lg shadow-emerald-600/20"
                 >
                   Authorize Payment
                 </button>
               )}
            </div>
          ) : (
            <div className="text-center py-10 text-zinc-400 text-[10px] font-black uppercase tracking-widest">No transaction records found</div>
          )}
        </Card>

        <Card title="House Rules" className="lg:col-span-1 border-none shadow-xl shadow-rose-100/30">
           <ul className="space-y-3">
             {[
               "Visitor access restricted after 22:00",
               "Quiet hours from 23:00 to 07:00",
               "Prohibited items strictly monitored"
             ].map((rule, i) => (
                <li key={i} className="flex items-center gap-3 text-xs font-medium text-zinc-600">
                  <div className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                  {rule}
                </li>
             ))}
           </ul>
        </Card>
      </div>
    </div>
  );
}
