import React from 'react';
import { motion } from 'motion/react';
import { CreditCard, AlertCircle, Building2, UserCircle } from 'lucide-react';
import { Card, Badge } from '../common/UI';

export function ResidentDashboard({ user, stats, setView }: any) {
  const myComplaints = stats.complaints.filter((c: any) => c.userId === user.id);
  const myLatestPayments = stats.payments.filter((p: any) => p.userId === user.id).slice(0, 3);

  return (
    <div className="space-y-8">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-indigo-600 rounded-[3rem] p-12 text-white relative overflow-hidden shadow-2xl shadow-indigo-600/30"
      >
        <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 blur-[120px] rounded-full -mr-32 -mt-32 animate-pulse" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-indigo-500/20 blur-[100px] rounded-full -ml-32 -mb-32" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-10">
          <div className="space-y-6">
            <div className="flex gap-3">
              <Badge variant="success">Active Sector</Badge>
              <div className="bg-white/10 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest backdrop-blur-md">Node {user.roomId || 'UNASSIGNED'}</div>
            </div>
            <h1 className="text-6xl font-black tracking-tighter leading-[0.9] uppercase">Terminal<br />Authorized,<br />{user.name.split(' ')[0]}.</h1>
            <p className="text-indigo-100 font-medium opacity-70 max-w-sm">Welcome to your administrative interface. All sector systems are operational.</p>
          </div>
          <div className="flex gap-4">
            <div className="bg-white/10 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/10 shadow-2xl">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-200 mb-2">Account Dues</p>
              <p className="text-4xl font-black mt-1 tracking-tighter">₹{stats.payments.filter((p:any)=>p.userId === user.id && p.status === 'Pending').reduce((s:number,p:any)=>s+p.amount, 0).toLocaleString()}</p>
            </div>
            <div className="bg-white/10 backdrop-blur-3xl p-8 rounded-[2.5rem] border border-white/10 shadow-2xl hidden sm:block">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-200 mb-2">Tickets</p>
              <p className="text-4xl font-black mt-1 tracking-tighter text-emerald-400">{myComplaints.length}</p>
            </div>
          </div>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card title="Quick Actions" className="bg-white border-none shadow-xl shadow-indigo-100/30">
          <div className="grid grid-cols-2 gap-4">
            <button onClick={() => setView('payments')} className="flex flex-col items-center gap-3 p-6 rounded-[2rem] bg-indigo-50 text-indigo-600 hover:bg-indigo-100 transition-all group">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                <CreditCard size={20} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-center">Finance</span>
            </button>
            <button onClick={() => setView('complaints')} className="flex flex-col items-center gap-3 p-6 rounded-[2rem] bg-rose-50 text-rose-600 hover:bg-rose-100 transition-all group">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                <AlertCircle size={20} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-center">Support</span>
            </button>
            <button onClick={() => setView('unit')} className="flex flex-col items-center gap-3 p-6 rounded-[2rem] bg-emerald-50 text-emerald-600 hover:bg-emerald-100 transition-all group">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                <Building2 size={20} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-center">Assignment</span>
            </button>
            <button onClick={() => setView('profile')} className="flex flex-col items-center gap-3 p-6 rounded-[2rem] bg-amber-50 text-amber-600 hover:bg-amber-100 transition-all group">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-sm group-hover:scale-110 transition-transform">
                <UserCircle size={20} />
              </div>
              <span className="text-[10px] font-black uppercase tracking-widest text-center">Identity</span>
            </button>
          </div>
        </Card>
        
        <Card title="Latest Transactions" className="bg-white border-none shadow-xl shadow-zinc-100/30">
          <div className="space-y-4">
            {myLatestPayments.length > 0 ? myLatestPayments.map((p: any) => (
              <div key={p.id} className="flex items-center justify-between p-4 bg-zinc-50 rounded-2xl border border-zinc-100">
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-zinc-400">{p.month} Billing</p>
                  <p className="text-xs font-black text-zinc-900">₹{p.amount.toLocaleString()}</p>
                </div>
                <Badge variant={p.status === 'Paid' ? 'success' : 'warning'}>{p.status}</Badge>
              </div>
            )) : (
              <div className="text-center py-10 text-zinc-400 text-[10px] font-black uppercase tracking-widest">No Protocol Logs</div>
            )}
          </div>
        </Card>

        <Card title="Gym Status" subtitle="Capacity Level" className="border-none shadow-xl shadow-emerald-100/30">
          <div className="flex flex-col items-center justify-center h-full py-4">
            <div className="relative w-32 h-32 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90">
                <circle cx="64" cy="64" r="58" className="stroke-zinc-100 fill-none" strokeWidth="12" />
                <circle cx="64" cy="64" r="58" className="stroke-emerald-500 fill-none" strokeWidth="12" strokeDasharray="364.4" strokeDashoffset="250" strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-2xl font-black text-zinc-900 leading-none">32%</span>
                <span className="text-[8px] font-black text-zinc-400 uppercase tracking-widest mt-1">Low Load</span>
              </div>
            </div>
            <p className="text-[10px] font-black text-zinc-400 uppercase tracking-widest mt-6">Open Until 11:00 PM</p>
          </div>
        </Card>
      </div>
    </div>
  );
}
