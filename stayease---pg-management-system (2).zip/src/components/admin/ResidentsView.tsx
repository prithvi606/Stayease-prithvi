import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, Plus, X, Building2, Edit3, Trash2, UserCircle } from 'lucide-react';
import { Card, Badge } from '../common/UI';
import { cn } from '../../utils';
import { User } from '../../types';

export function ResidentsView({ users, setUsers, rooms, setRooms }: any) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const residents = users.filter((u: any) => u.role === 'resident');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as any;
    const roomId = form.roomId.value;
    
    const newUser: User = {
      id: `u${Date.now()}`,
      name: form.name.value,
      email: form.email.value,
      role: 'resident',
      phone: form.phone.value,
      roomId: roomId || undefined,
    };

    setUsers([...users, newUser]);

    if (roomId) {
      setRooms(rooms.map((r: any) => {
        if (r.id === roomId) {
          const newOccupancy = r.occupancy + 1;
          return { 
            ...r, 
            occupancy: newOccupancy,
            status: newOccupancy >= r.capacity ? 'Full' : 'Available'
          };
        }
        return r;
      }));
    }

    setIsAdding(false);
  };

  const handleEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    const form = e.target as any;
    const newRoomId = form.roomId.value;
    const oldRoomId = editingUser.roomId;

    const updatedUser = {
      ...editingUser,
      name: form.name.value,
      email: form.email.value,
      phone: form.phone.value,
      roomId: newRoomId || undefined,
    };

    setUsers(users.map((u: User) => u.id === editingUser.id ? updatedUser : u));

    // Handle room occupancy logic if room changed
    if (newRoomId !== oldRoomId) {
      setRooms(rooms.map((r: any) => {
        if (r.id === oldRoomId) {
          return { ...r, occupancy: Math.max(0, r.occupancy - 1), status: 'Available' };
        }
        if (r.id === newRoomId) {
          const newOccupancy = r.occupancy + 1;
          return { ...r, occupancy: newOccupancy, status: newOccupancy >= r.capacity ? 'Full' : 'Available' };
        }
        return r;
      }));
    }

    setEditingUser(null);
  };

  const handleDelete = (id: string) => {
    const userToDelete = users.find((u: any) => u.id === id);
    if (!userToDelete) return;

    if (userToDelete.roomId) {
      setRooms(rooms.map((r: any) => {
        if (r.id === userToDelete.roomId) {
          const newOccupancy = Math.max(0, r.occupancy - 1);
          return { 
            ...r, 
            occupancy: newOccupancy,
            status: 'Available'
          };
        }
        return r;
      }));
    }

    setUsers(users.filter((u: any) => u.id !== id));
  };

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-black text-zinc-900 tracking-tighter uppercase">Personnel Directory</h1>
        <div className="flex gap-3">
           <div className="flex items-center bg-white border border-zinc-200 px-4 py-2 rounded-2xl gap-3 text-zinc-400 shadow-sm">
              <Search size={18} />
              <input type="text" placeholder="Search entries..." className="bg-transparent border-none outline-none text-[10px] font-black uppercase tracking-widest placeholder:text-zinc-300" />
            </div>
            <button 
              onClick={() => { setIsAdding(true); setEditingUser(null); }}
              className="bg-zinc-900 text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-zinc-800 transition shadow-xl shadow-zinc-900/10"
            >
              <Plus size={18} /> Enroll User
            </button>
        </div>
      </div>

      <AnimatePresence>
        {(isAdding || editingUser) && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="mb-8 p-8 bg-zinc-900 rounded-[2.5rem] text-white">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-black uppercase tracking-tighter">{editingUser ? 'Member Modification' : 'Member Enrollment'}</h3>
              <button onClick={() => { setIsAdding(false); setEditingUser(null); }} className="text-zinc-500 hover:text-white"><X size={20} /></button>
            </div>
            <form onSubmit={editingUser ? handleEdit : handleAdd} className="grid grid-cols-1 md:grid-cols-5 gap-4">
              <input name="name" defaultValue={editingUser?.name} type="text" placeholder="Full Name" required className="bg-white/10 border border-white/20 rounded-xl p-3 text-xs font-bold outline-none col-span-1 md:col-span-1" />
              <input name="email" defaultValue={editingUser?.email} type="email" placeholder="Email Address" required className="bg-white/10 border border-white/20 rounded-xl p-3 text-xs font-bold outline-none col-span-1 md:col-span-1" />
              <input name="phone" defaultValue={editingUser?.phone} type="text" placeholder="Phone Number" required className="bg-white/10 border border-white/20 rounded-xl p-3 text-xs font-bold outline-none col-span-1 md:col-span-1" />
              <select name="roomId" defaultValue={editingUser?.roomId} className="bg-white/10 border border-white/20 rounded-xl p-3 text-xs font-bold outline-none appearance-none col-span-1 md:col-span-1">
                 <option value="" className="text-black">Unassigned</option>
                 {rooms.map((r:any) => (
                   <option key={r.id} value={r.id} className="text-black" disabled={r.status === 'Full' && r.id !== editingUser?.roomId}>Node {r.number} {r.status === 'Full' && r.id !== editingUser?.roomId ? '(Full)' : ''}</option>
                 ))}
              </select>
              <button type="submit" className="md:col-span-1 bg-white text-zinc-900 font-black uppercase text-[10px] tracking-widest rounded-xl hover:bg-zinc-200 transition">
                {editingUser ? 'Update' : 'Execute'}
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <Card className="p-0 overflow-hidden shadow-2xl shadow-zinc-200/50">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-zinc-50 border-b border-zinc-200">
                <th className="px-8 py-5 text-[10px] font-black text-zinc-400 uppercase tracking-widest">Profile</th>
                <th className="px-8 py-5 text-[10px] font-black text-zinc-400 uppercase tracking-widest">Connectivity</th>
                <th className="px-8 py-5 text-[10px] font-black text-zinc-400 uppercase tracking-widest">Node Path</th>
                <th className="px-8 py-5 text-[10px] font-black text-zinc-400 uppercase tracking-widest">Status</th>
                <th className="px-8 py-5 text-[10px] font-black text-zinc-400 uppercase tracking-widest text-right">Registry</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-100">
              {residents.map((r: User) => {
                const room = rooms.find((rm: any) => rm.id === r.roomId);
                const colors = ['bg-indigo-600', 'bg-emerald-600', 'bg-rose-600', 'bg-amber-500', 'bg-purple-600', 'bg-cyan-600'];
                const colorClass = colors[r.id.charCodeAt(r.id.length-1) % colors.length];
                
                return (
                  <tr key={r.id} className="hover:bg-zinc-50/50 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center text-white font-black border-none shadow-lg text-lg group-hover:scale-110 transition-transform", colorClass)}>
                          {r.name[0]}
                        </div>
                        <div>
                          <p className="font-black text-zinc-900 text-sm tracking-tight">{r.name}</p>
                          <p className="text-[10px] text-zinc-400 font-black uppercase tracking-[0.2em] mt-0.5">{r.id.toUpperCase()}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <p className="text-[11px] font-black text-zinc-900 uppercase tracking-tight">{r.email}</p>
                      <p className="text-[10px] text-zinc-400 font-bold mt-1 tracking-widest">{r.phone}</p>
                    </td>
                    <td className="px-8 py-6">
                      {room ? (
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-xl bg-zinc-100 flex items-center justify-center text-zinc-900 border border-zinc-200">
                            <Building2 size={16} />
                          </div>
                          <div>
                            <p className="text-xs font-black text-zinc-900 uppercase tracking-tight">Node {room.number}</p>
                            <p className="text-[10px] text-zinc-400 font-black uppercase tracking-[0.2em]">{room.type}</p>
                          </div>
                        </div>
                      ) : (
                        <Badge variant="warning">In Queue</Badge>
                      )}
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                        <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Active Link</span>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex items-center justify-end gap-3">
                        <button 
                          onClick={() => { setEditingUser(r); setIsAdding(false); }}
                          className="p-3 bg-zinc-50 border border-zinc-200 rounded-xl text-zinc-400 hover:text-zinc-900 hover:border-zinc-900 transition shadow-sm"
                        >
                          <Edit3 size={16} />
                        </button>
                        <button 
                          onClick={() => handleDelete(r.id)}
                          className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-rose-300 hover:text-rose-600 hover:border-rose-600 transition shadow-sm"
                        >
                          <Trash2 size={16} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
