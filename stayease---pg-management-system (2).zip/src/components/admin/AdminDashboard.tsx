import React from 'react';
import { motion } from 'motion/react';
import { CreditCard, Users, Building2, AlertCircle, TrendingUp, TrendingDown, CheckCircle2, Clock, Bell, MessageSquare, Plus } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, PieChart, Pie, Cell } from 'recharts';
import { StatCard, Card, Badge } from '../common/UI';
import { cn } from '../../utils';

export function AdminDashboard({ stats, setView }: any) {
  const currentPayments = stats.payments.filter((p: any) => p.status === 'Paid');
  const revenue = currentPayments.reduce((acc: number, p: any) => acc + p.amount, 0);
  
  const chartData = [
    { name: 'Mon', revenue: 12000 },
    { name: 'Tue', revenue: 45000 },
    { name: 'Wed', revenue: 23000 },
    { name: 'Thu', revenue: 85000 },
    { name: 'Fri', revenue: 48000 },
    { name: 'Sat', revenue: 95000 },
    { name: 'Sun', revenue: 32000 },
  ];

  const pieData = [
    { name: 'Occupied', value: stats.rooms.filter((r: any) => r.status === 'Full').length },
    { name: 'Available', value: stats.rooms.filter((r: any) => r.status === 'Available').length },
    { name: 'Maintenance', value: stats.rooms.filter((r: any) => r.status === 'Maintenance').length },
  ];

  const COLORS = ['#2563eb', '#10b981', '#f59e0b', '#7c3aed', '#e11d48'];

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
        <div>
          <h1 className="text-6xl font-black text-zinc-900 tracking-[ -0.05em] uppercase leading-[0.8] mb-4">Command<br/>Center.</h1>
          <p className="text-zinc-400 text-[10px] font-black uppercase tracking-[0.3em] flex items-center gap-2">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.5)]" />
            Live Sector Telemetry
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => alert('Data serialization in progress... Check your downloads folder.')}
            className="bg-white border border-zinc-200 px-8 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest hover:bg-zinc-50 transition shadow-xl shadow-zinc-200/40"
          >
            Export Data
          </button>
          <button 
            onClick={() => alert('Synchronizing with central command... System is up to date.')}
            className="bg-zinc-900 text-white px-8 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition shadow-2xl shadow-zinc-900/30"
          >
            System Update
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard label="Total Revenue" value={`₹${revenue.toLocaleString()}`} icon={CreditCard} trend={12} color="bg-blue-600 shadow-blue-600/30" />
        <StatCard label="Active Tenants" value={stats.users.filter((u: any) => u.role === 'resident').length} icon={Users} trend={5} color="bg-purple-600 shadow-purple-600/30" />
        <StatCard label="Occupancy Matrix" value={`${((stats.rooms.filter((r: any) => r.status === 'Full').length / stats.rooms.length) * 100).toFixed(0)}%`} icon={Building2} trend={-2} color="bg-emerald-600 shadow-emerald-600/30" />
        <StatCard label="Terminal Alerts" value={stats.complaints.filter((c: any) => c.status !== 'Resolved').length} icon={AlertCircle} trend={15} color="bg-rose-600 shadow-rose-600/30" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 shadow-2xl shadow-blue-600/5 group" title="Revenue Velocity" subtitle="Weekly collection performance">
          <div className="h-80 w-full mt-6">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f8fafc" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 900}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 900}} tickFormatter={(value: number) => `₹${value/1000}k`} />
                <Tooltip 
                  contentStyle={{backgroundColor: '#ffffff', border: 'none', borderRadius: '24px', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.1)', padding: '20px'}}
                  itemStyle={{fontSize: '12px', fontWeight: '900', textTransform: 'uppercase', letterSpacing: '0.1em'}}
                />
                <Area type="monotone" dataKey="revenue" stroke="#2563eb" strokeWidth={5} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Allocation" subtitle="Resource distribution" className="shadow-2xl shadow-purple-600/5 text-center">
          <div className="h-64 w-full mt-6">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} innerRadius={75} outerRadius={95} paddingAngle={10} dataKey="value" strokeWidth={0}>
                  {pieData.map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} className="outline-none" />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{borderRadius: '24px', border: 'none', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.1)', padding: '20px'}}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center flex-wrap gap-4 mt-8 px-4">
            {pieData.map((item, index) => (
              <div key={item.name} className="flex flex-col items-center flex-1 min-w-[60px]">
                <div className="w-6 h-1.5 rounded-full mb-2" style={{backgroundColor: COLORS[index]}} />
                <span className="text-[9px] font-black text-zinc-400 uppercase tracking-widest">{item.name}</span>
                <span className="text-xs font-black text-zinc-900 mt-1">{item.value}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card title="Terminal Feed" action={
          <button 
            onClick={() => setView('complaints')}
            className="bg-zinc-900 text-white px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition shadow-lg shadow-zinc-900/10"
          >
            Full Log
          </button>
        }>
          <div className="space-y-4 mt-8">
            {stats.complaints.slice(0, 3).map((c: any) => (
              <div key={c.id} className="flex items-center gap-6 p-6 rounded-[2rem] bg-zinc-50 border border-zinc-100/50 hover:border-zinc-300 transition-all duration-300 group">
                <div className={cn(
                  "w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-sm transition-transform group-hover:scale-110",
                  c.status === 'Resolved' ? 'bg-emerald-500 text-white shadow-emerald-500/20' : 
                  c.status === 'In-Progress' ? 'bg-blue-600 text-white shadow-blue-600/20' : 'bg-rose-600 text-white shadow-rose-600/20'
                )}>
                  {c.status === 'Resolved' ? <CheckCircle2 size={24} /> : c.status === 'In-Progress' ? <Clock size={24} /> : <AlertCircle size={24} />}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-black text-xs uppercase tracking-wider truncate text-zinc-900">{c.title}</h4>
                  <p className="text-[10px] text-zinc-400 font-bold mt-1 uppercase tracking-widest opacity-60">ID: {c.id} · {c.category} · {c.createdAt}</p>
                </div>
                <div className="hidden sm:block">
                   <Badge variant={c.status === 'Resolved' ? 'success' : c.status === 'In-Progress' ? 'info' : 'danger'}>{c.status}</Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card title="Quick Terminal" subtitle="Operational shortcuts">
          <div className="grid grid-cols-2 gap-4 mt-6">
            {[
              { label: 'Register Payment', icon: Plus, color: 'text-blue-600 bg-blue-50', view: 'payments' },
              { label: 'Add Room', icon: Building2, color: 'text-emerald-600 bg-emerald-50', view: 'rooms' },
              { label: 'Post Notice', icon: Bell, color: 'text-amber-600 bg-amber-50', view: 'notices' },
              { label: 'Global Chat', icon: MessageSquare, color: 'text-purple-600 bg-purple-50', view: 'feedback' }
            ].map((task) => (
              <button 
                key={task.label} 
                onClick={() => setView(task.view)}
                className="p-6 rounded-[2rem] bg-white border border-zinc-200 hover:border-zinc-400 hover:bg-zinc-50 transition-all text-left flex flex-col gap-4 group shadow-sm"
              >
                <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center transition-all group-hover:scale-110 shadow-inner", task.color)}>
                  <task.icon size={24} />
                </div>
                <span className="font-black text-[10px] uppercase tracking-widest text-zinc-900">{task.label}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
