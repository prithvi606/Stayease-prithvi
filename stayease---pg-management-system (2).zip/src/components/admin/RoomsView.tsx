import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, X, Trash2 } from 'lucide-react';
import { Badge } from '../common/UI';
import { cn } from '../../utils';
import { Room } from '../../types';

export function RoomsView({ rooms, setRooms }: any) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [activeTab, setActiveTab] = useState('All');

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as any;
    const newRoom: Room = {
      id: `r${Date.now()}`,
      number: form.number.value,
      type: form.type.value,
      rent: Number(form.rent.value),
      capacity: Number(form.capacity.value),
      occupancy: 0,
      status: 'Available',
      floor: Number(form.floor.value),
      amenities: ['WiFi'],
    };
    setRooms([newRoom, ...rooms]);
    setIsAdding(false);
  };

  const handleEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRoom) return;
    const form = e.target as any;
    
    const capacity = Number(form.capacity.value);
    const occupancy = editingRoom.occupancy;
    
    const updatedRoom: Room = {
      ...editingRoom,
      number: form.number.value,
      type: form.type.value,
      rent: Number(form.rent.value),
      capacity: capacity,
      floor: Number(form.floor.value),
      status: occupancy >= capacity ? 'Full' : editingRoom.status === 'Maintenance' ? 'Maintenance' : 'Available'
    };
    
    setRooms(rooms.map((r: any) => r.id === editingRoom.id ? updatedRoom : r));
    setEditingRoom(null);
  };

  const handleDelete = (id: string) => {
    setRooms(rooms.filter((r: any) => r.id !== id));
  };

  const filtered = activeTab === 'All' ? rooms : rooms.filter((r: any) => r.status === activeTab);

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex bg-zinc-100 p-1 rounded-2xl">
          {['All', 'Available', 'Full', 'Maintenance'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all duration-300",
                activeTab === tab ? "bg-white text-zinc-900 shadow-lg shadow-zinc-200/50" : "text-zinc-400 hover:text-zinc-600"
              )}
            >
              {tab}
            </button>
          ))}
        </div>
        <button 
          onClick={() => setIsAdding(true)}
          className="bg-zinc-900 text-white px-8 py-4 rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest flex items-center gap-3 hover:bg-zinc-800 transition shadow-2xl shadow-zinc-900/20"
        >
          <Plus size={18} /> Provision Node
        </button>
      </div>

      <AnimatePresence>
        {(isAdding || editingRoom) && (
          <motion.div initial={{ opacity: 0, y: -20, scale: 0.95 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: -20, scale: 0.95 }} className="mb-10 p-12 bg-zinc-900 rounded-[3.5rem] text-white shadow-3xl">
            <div className="flex justify-between items-center mb-8">
              <h3 className="text-3xl font-black uppercase tracking-tighter">{editingRoom ? 'Reconfigure Operational Node' : 'New Node Provisioning'}</h3>
              <button onClick={() => { setIsAdding(false); setEditingRoom(null); }} className="text-zinc-500 hover:text-white transition-colors"><X size={28} /></button>
            </div>
            <form onSubmit={editingRoom ? handleEdit : handleAdd} className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Room Number</label>
                <input name="number" defaultValue={editingRoom?.number} type="text" placeholder="101" required className="w-full bg-white/10 border border-white/20 rounded-2xl p-4 text-sm font-bold outline-none focus:ring-2 focus:ring-white/20" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Suite Type</label>
                <select name="type" defaultValue={editingRoom?.type} className="w-full bg-white/10 border border-white/20 rounded-2xl p-4 text-sm font-bold outline-none appearance-none">
                  <option value="Single" className="text-black">Single Suite</option>
                  <option value="Double" className="text-black">Double Suite</option>
                  <option value="Triple" className="text-black">Triple Suite</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Monthly Rent (₹)</label>
                <input name="rent" defaultValue={editingRoom?.rent} type="number" placeholder="12000" required className="w-full bg-white/10 border border-white/20 rounded-2xl p-4 text-sm font-bold outline-none focus:ring-2 focus:ring-white/20" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Capacity</label>
                <input name="capacity" defaultValue={editingRoom?.capacity} type="number" placeholder="1" required className="w-full bg-white/10 border border-white/20 rounded-2xl p-4 text-sm font-bold outline-none focus:ring-2 focus:ring-white/20" />
              </div>
              <div className="space-y-2 md:col-span-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-zinc-500">Floor Level</label>
                <input name="floor" defaultValue={editingRoom?.floor} type="number" placeholder="1" required className="w-full bg-white/10 border border-white/20 rounded-2xl p-4 text-sm font-bold outline-none focus:ring-2 focus:ring-white/20" />
              </div>
              <button type="submit" className="md:col-span-2 bg-white text-zinc-900 font-black uppercase text-[12px] tracking-widest rounded-2xl hover:bg-zinc-200 transition mt-auto h-[60px]">
                {editingRoom ? 'Update Configuration' : 'Execute Deployment'}
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
        {filtered.map((room: Room) => (
          <motion.div 
            layoutId={room.id}
            key={room.id} 
            className="bg-white border border-zinc-200 rounded-[2.5rem] p-8 hover:border-zinc-300 transition-all group shadow-sm shadow-zinc-200/50 relative overflow-hidden"
          >
            <div className={cn(
              "absolute top-0 right-0 w-32 h-32 blur-3xl opacity-0 group-hover:opacity-20 transition-opacity duration-700 -mr-16 -mt-16",
              room.status === 'Available' ? 'bg-emerald-500' : room.status === 'Full' ? 'bg-rose-500' : 'bg-amber-500'
            )} />
            
            <div className="flex items-center justify-between mb-8 relative z-10">
              <span className="text-4xl font-black text-zinc-900 group-hover:scale-110 transition-transform origin-left tracking-tighter">#{room.number}</span>
              <Badge variant={room.status === 'Available' ? 'success' : room.status === 'Full' ? 'danger' : 'warning'}>
                {room.status}
              </Badge>
            </div>
            
            <div className="space-y-4 relative z-10">
              <div className="flex justify-between">
                <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Model</span>
                <span className="text-[11px] font-black text-zinc-900 uppercase tracking-tight">{room.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[10px] font-black text-zinc-400 uppercase tracking-widest">Sector</span>
                <span className="text-[11px] font-black text-zinc-900 uppercase tracking-tight">Phase {room.floor}</span>
              </div>
              <div className="pt-6 border-t border-zinc-100">
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-[9px] uppercase font-black text-zinc-400 tracking-[0.2em] mb-1">Operational Cost</p>
                    <p className="text-2xl font-black text-zinc-900 tracking-tight">₹{room.rent.toLocaleString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-[9px] uppercase font-black text-zinc-400 tracking-[0.2em] mb-1">Load</p>
                    <p className="text-sm font-black text-zinc-900">{room.occupancy}/{room.capacity}</p>
                  </div>
                </div>
              </div>

              {/* Progress Bar for Occupancy */}
              <div className="w-full h-3 bg-zinc-100 rounded-full overflow-hidden shadow-inner">
                <div 
                  className={cn(
                    "h-full rounded-full transition-all duration-700 ease-out", 
                    room.occupancy >= room.capacity ? "bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.5)]" : "bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                  )}
                  style={{ width: `${(room.occupancy / room.capacity) * 100}%` }}
                />
              </div>
            </div>

            <div className="mt-8 flex gap-3 relative z-10">
              <button 
                onClick={() => { setEditingRoom(room); setIsAdding(false); }}
                className="flex-1 bg-zinc-900 text-white py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-zinc-800 transition shadow-lg shadow-zinc-900/10"
              >
                Configure
              </button>
              <button 
                onClick={() => handleDelete(room.id)}
                className="p-3 bg-zinc-100 text-zinc-400 rounded-xl hover:bg-rose-50 hover:text-rose-600 transition"
              >
                <Trash2 size={16} />
              </button>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
